<?php

include "db_connection.php";

function dbQuery(string $sql, array $params = [], bool $exec = false) {
    if (empty($sql)) return false;

    $query = dbConnect()->prepare($sql);
    $query->execute($params);

    if ($exec) return true;

    return $query;
}

function getAll(string $tableName) {
    return dbQuery("SELECT * FROM {$tableName}")->fetchAll();
}

function getLikeByUserId(int $userId, int $newsId) {
    $params = [
        'user_id' => $userId,
        'news_id' => $newsId
    ];
    $sql = "SELECT count(*) FROM `votes_news2user` WHERE `id_user` = :user_id AND `id_news` = :news_id;" ;

    return dbQuery($sql, $params);
}

function updateNewsLike(int $newsId) {
    $params = [
        'news_id' => $newsId,
    ];

    $sql = "UPDATE `news` SET `count_like` = `count_like` + 1 WHERE  `id` = :news_id";
    return dbQuery($sql, $params, true);
}

function updateNewsDisLike(int $newsId) {
    $params = [
        'news_id' => $newsId
    ];

    $sql = "UPDATE `news` SET `count_dislike` = `count_dislike`  + 1 WHERE  `id` = :news_id";
    return dbQuery($sql, $params, true);
}

function addLike(int $userId, int $newsId, string $likeType) {
    $params = [
        'user_id' => $userId,
        'news_id' => $newsId
    ];

    $sql = "INSERT INTO `votes_news2user` (`id_user`, `id_news`) VALUES (:user_id , :news_id)";
    if (dbQuery($sql, $params, true)) {
        // проверяем лайк или дизлайк и обновляем бд
        if ($likeType == 'like') updateNewsLike($newsId);
        if ($likeType == 'dislike') updateNewsDisLike($newsId);
        return true;
    }

    return false;
}