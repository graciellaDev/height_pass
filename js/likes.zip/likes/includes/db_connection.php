<?php

const DB_HOST = 'localhost';
const DB_NAME = 'news-likes';
const DB_USER = 'root';
const DB_PASS = 'root';
const DB_CHARSET = 'utf8';

function dbConnect() {

    $pdoOptions = [
      PDO::ATTR_EMULATE_PREPARES => false,
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ];

    static $connect = null;

    if ($connect === null) {
        try {
            $connect = new PDO(
                "mysql:host=" . DB_HOST .
                    ";dbname=" . DB_NAME .
                    ";charset=" . DB_CHARSET,
                DB_USER, DB_PASS,
                $pdoOptions
            );
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    return $connect;
}
