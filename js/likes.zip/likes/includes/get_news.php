<?php

include_once 'functions.php';

// получаем все посты

if (isset($_POST)) {
    echo json_encode(getAll('news'));
} else {
    header('Location: /');
}