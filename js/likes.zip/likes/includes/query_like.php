<?php

include "functions.php";

// контейнер для ошибок
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestBody = json_decode(file_get_contents('php://input', true), true);
    foreach ($requestBody as $key => $value) {
        $_POST[$key] = $value;
    }
}

if (!isset($_POST['id_user']) || empty($_POST['id_user']) &&
    !isset($_POST['id_news']) || empty($_POST['id_news']) &&
    !isset($_POST['type']) || empty($_POST['type']) ) {
    echo json_encode(array('error' => 'Неизвестная ошибка'));
    exit();
//    header("Location: /");
}

// получем поле для голосования - лайк или дизлайк
$type = $_POST['type'];
// проверяем, голосовал ранее пользователь за эту новость или нет
$result = getLikeByUserId($_POST['id_user'], $_POST['id_news'])->fetchColumn();

// если что-то пришло из запроса, значит уже голосовал
if ($result > 0) {
    $error = 'Вы уже голосовали';
} else { // если пользователь не голосовал, проголосуем
    // делаем запись о том, что пользователь проголосовал
    addLike($_POST['id_user'], $_POST['id_news'], $type);
}

// делаем ответ для клиента
if($error){
    // если есть ошибки то отправляем ошибку и ее текст
    echo json_encode(array('result' => 'error', 'msg' => $error));
}else{
    // если нет ошибок сообщаем об успехе
    echo json_encode(array('result' => 'success'));
}

//header("Location: /");