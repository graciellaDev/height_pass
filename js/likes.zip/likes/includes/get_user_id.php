<?php

// при необходимости дописать логику для запроса айди пользователя

if (isset($_POST)) {
    echo 1;
} else {
    header('Location: /');
}
