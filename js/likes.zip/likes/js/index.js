// получаем контейнер с постами
const newsListEl = document.querySelector('.news-list');

// определяем пути для запросов
const urlGetNews = 'includes/get_news.php';
const urlGetUserId = 'includes/get_user_id.php';
const urlSetLike = 'includes/query_like.php';

// запрос на добавление лайка
async function setLike(params) {
    const data = await fetch(urlSetLike, {
        method: 'POST',
        body: JSON.stringify(params),
    });
    return await data.json();
}

// запрос на получение id пользователя
async function getUserId() {
    const data = await fetch(urlGetUserId, {
        method: 'POST'
    });
    const result = await data.json();
    return result;
}

// запрос на получения всех постов
async function getAllNews() {
    const data = await fetch(urlGetNews, {
        method: 'POST'
    });
    const result = await data.json();

    return result;
}

// вывод постов на страницу
const renderNews = async (idNews = '', status = '') => {
    const news = await getAllNews();
    newsListEl.innerHTML = '';
    let newsList = '';
    news.forEach(item => {
        newsList += `
        <li class="one_news" id="${item.id}">
          <h3>${item.title}</h3>
          <p>${item.title}</p>
          <button data-like-type="like" type="button">Like (<b style="pointer-events: none">${item.count_like}</b>)</button>
          <button data-like-type="dislike" type="button">DisLike (<b style="pointer-events: none">${item.count_dislike}</b>)</button>
          
          <small style="color:red">${(item.id === idNews && status.msg) ? status.msg : '' }</small>
        </li>
        `;
        // в тэг small при наличии ошибки добавляем текст ошибки
    });
    newsListEl.insertAdjacentHTML('afterbegin', newsList);
}

renderNews();

// обработка клика, для добавления лайка
newsListEl.addEventListener('click', async ({ target }) => {

    if (target.closest('[data-like-type]')) {
        const newsId = parseInt(target.parentNode.id);
        const id = await getUserId();
        const likeAnswer = await setLike({
            'id_user': id,
            'id_news': newsId,
            'type': target.dataset.likeType
        })

        renderNews(newsId, likeAnswer);
    }
});
