<?php
include_once "includes/functions.php";

//$userId = 1; // id пользователя
//// достаем все новости
//$news = getAll('news');

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>News Likes/DisLikes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="js/index.js" defer></script>
  <style>
      .one_news span {
          border: 1px dotted;
          cursor: pointer;
          display: block;
          margin-bottom: 5px;
          text-align: center;
          width: 85px;
      }
      .one_news span:hover{
          border: 1px solid;
      }
  </style>
</head>
<body>
<div class="container">
  <ul class="news-list">

<!-- так как посты грузятся средствами аякс, то код ниже не нужен -->


<!--      --><?php //foreach($news as $oneNews){ ?>
<!--        <div class="one_news">-->
<!--          <h3>--><?//=$oneNews['title'];?><!--</h3>-->
<!--          <p>--><?//=$oneNews['title'];?><!--</p>-->
<!--          <form action="includes/query_like.php" method="post">-->
<!--            <input type="hidden" id="id_user" name="id_user" value="--><?//=$userId;?><!--" />-->
<!--            <input type="hidden" id="id_news" name="id_news" value="--><?//=$oneNews['id'];?><!--" />-->
<!--            <input type="hidden" id="type" name="type" value="like" />-->
<!--            <button id="like">Like (<b>--><?//=$oneNews['count_like'];?><!--</b>)</button>-->
<!--          </form>-->
<!---->
<!--          <form action="includes/query_like.php" method="post">-->
<!--            <input type="hidden" id="id_user" name="id_user" value="--><?//=$userId;?><!--" />-->
<!--            <input type="hidden" id="id_news" name="id_news" value="--><?//=$oneNews['id'];?><!--" />-->
<!--            <input type="hidden" id="type" name="type" value="dislike" />-->
<!--            <button id="dislike">DisLike (<b>--><?//=$oneNews['count_dislike'];?><!--</b>)</button>-->
<!--          </form>-->
<!---->
<!--        </div>-->
<!--        <hr/>-->
<!--      --><?php //} ?>
  </ul>


</div>
</body>
</html>
